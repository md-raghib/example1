package com.csc.bean;

public class Asset {
private int assetId;
private String assetName;
private String warrantyDate;
private String makeDate;
private int price;
private String description;
public int getAssetId() {
	return assetId;
}
public void setAssetId(int assetId) {
	this.assetId = assetId;
}
public String getAssetName() {
	return assetName;
}
public void setAssetName(String assetName) {
	this.assetName = assetName;
}
public String getWarrantyDate() {
	return warrantyDate;
}
public void setWarrantyDate(String warrantyDate) {
	this.warrantyDate = warrantyDate;
}
public String getMakeDate() {
	return makeDate;
}
public void setMakeDate(String makeDate) {
	this.makeDate = makeDate;
}
public int getPrice() {
	return price;
}
public void setPrice(int price) {
	this.price = price;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}

}
