package com.csc.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.csc.bean.User;

public class AdminDAO {

	private static Connection conn;

	public AdminDAO() {
	}

	public static void connect() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager
					.getConnection("jdbc:mysql://localhost/asset_management?" + "user=root&password=cscindia@123");
		} catch (ClassNotFoundException ce) {
			ce.printStackTrace();
		} catch (SQLException se) {
			se.printStackTrace();
		}
	}// connect

	public static boolean createUser(User user) {
		PreparedStatement pmt = null;

		try {
			pmt = conn.prepareStatement("insert into user values(?,?,?,?,?,?,?,?,?,?,?)");
			pmt.setInt(1, user.getUserId());
			pmt.setInt(2, user.getManagerId());
			pmt.setString(3, user.getFirstName());
			pmt.setString(4, user.getLastName());
			pmt.setString(5, user.getEmail());
			pmt.setString(6, user.getPassword());
			pmt.setString(7, user.getShortId());
			pmt.setInt(8, user.getMobileNumber());
			pmt.setString(9, user.getDateOfJoining());
			pmt.setString(10, user.getIsActive());
			pmt.setString(11, user.getUserType());
			

			int n = pmt.executeUpdate();
			if (n > 0)
				return true;
		} catch (SQLException se) {
			se.printStackTrace();
		} finally {
			try {
				if (pmt != null) {
					pmt.close();
				}

				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}
		}
		return false;
	}// createUser

	public static ArrayList<User> displayUser() {
		try {
			String query = "Select * from user";
			PreparedStatement pmt = conn.prepareStatement(query);
			ResultSet rs = pmt.executeQuery();
			ArrayList<User> al = new ArrayList<>();
			while (rs.next()) {
				User user = new User();
				user.setUserId(rs.getInt(1));
				user.setManagerId(rs.getInt(2));
				user.setFirstName(rs.getString(3));
				user.setLastName(rs.getString(4));
				user.setEmail(rs.getString(5));
				user.setPassword(rs.getString(6));
				user.setShortId(rs.getString(7));
				user.setMobileNumber(rs.getInt(8));
				user.setDateOfJoining(rs.getString(9));
				user.setIsActive(rs.getString(10));
				al.add(user);

			}
			return al;

		} catch (SQLException se) {
			se.printStackTrace();
		}
		return null;
	}
	public static User displayUserModify(User user) {
		try {
			String query = "Select * from user where user_id=?";
			PreparedStatement pmt = conn.prepareStatement(query);
			pmt.setInt(1, user.getUserId());
			ResultSet rs = pmt.executeQuery();
			
			while (rs.next()) {
				
				user.setUserId(rs.getInt(1));
				user.setManagerId(rs.getInt(2));
				user.setFirstName(rs.getString(3));
				user.setLastName(rs.getString(4));
				user.setEmail(rs.getString(5));
				user.setPassword(rs.getString(6));
				user.setShortId(rs.getString(7));
				user.setMobileNumber(rs.getInt(8));
				user.setDateOfJoining(rs.getString(9));
				user.setIsActive(rs.getString(10));
				
				return user;
			}
			

		} catch (SQLException se) {
			se.printStackTrace();
		}
		return null;
	}

	public static boolean updateUser(User user) {
		try {
			String query = "update user set manager_Id=?,first_name=?,last_name=?,email=?,password=?,short_id=?,mobile=?,date_of_joining=?,active=?,user_type=? where user_id=?";
			PreparedStatement pmt = conn.prepareStatement(query);
			pmt.setInt(1, user.getManagerId());
			pmt.setString(2, user.getFirstName());
			pmt.setString(3, user.getLastName());
			pmt.setString(4, user.getEmail());
			pmt.setString(5, user.getPassword());
			pmt.setString(6, user.getShortId());
			pmt.setInt(7, user.getMobileNumber());
			pmt.setString(8, user.getDateOfJoining());
			pmt.setString(9, user.getIsActive());
			pmt.setString(10, user.getUserType());
			pmt.setInt(11, user.getUserId());

			int n = pmt.executeUpdate();
			if (n > 0)
				return true;

		} catch (SQLException se) {
			se.printStackTrace();
		}
		return false;
	}
}
