package com.csc.employee;

import java.util.ArrayList;

import com.csc.bean.*;
import com.csc.service.EmployeeService;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

@SuppressWarnings({ "serial", "rawtypes" })
public class ViewAssetAction extends ActionSupport implements ModelDriven{
ArrayList<ViewAsset> viewasset=new ArrayList<>();

	
	public ArrayList<ViewAsset> getViewasset() {
	return viewasset;
}
public void setViewasset(ArrayList<ViewAsset> viewasset) {
	this.viewasset = viewasset;
}
	@Override
	public Object getModel() {
		
		return viewasset;
	}
	public String execute() {
		EmployeeService as=new EmployeeService();
		viewasset=as.displayAsset();
		
			return SUCCESS;
		
		
	}
}
