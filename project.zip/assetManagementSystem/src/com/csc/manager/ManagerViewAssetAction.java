package com.csc.manager;

import java.util.ArrayList;

import com.csc.bean.*;
import com.csc.service.*;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

@SuppressWarnings({ "serial", "rawtypes" })
public class ManagerViewAssetAction extends ActionSupport implements ModelDriven{
ArrayList<ViewAsset> viewasset=new ArrayList<>();

	
	public ArrayList<ViewAsset> getViewasset() {
	return viewasset;
}
public void setViewasset(ArrayList<ViewAsset> viewasset) {
	this.viewasset = viewasset;
}
	@Override
	public Object getModel() {
		
		return viewasset;
	}
	public String execute() {
		ManagerService as=new ManagerService();
		viewasset=as.displayAsset();
		
			return SUCCESS;
		
		
	}
}
