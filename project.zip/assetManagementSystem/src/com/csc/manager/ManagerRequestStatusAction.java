package com.csc.manager;

import java.util.ArrayList;

import com.csc.bean.Request;

import com.csc.service.ManagerService;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

@SuppressWarnings({ "serial", "rawtypes" })
public class ManagerRequestStatusAction extends ActionSupport implements ModelDriven {
ArrayList<Request> statusList=new ArrayList<>();
	
	
	
	public ArrayList<Request> getStatusList() {
	return statusList;
}
public void setStatusList(ArrayList<Request> statusList) {
	this.statusList = statusList;
}
	public String execute() {
		ManagerService rs=new ManagerService();
		statusList=rs.displayStatus();
	
	
		return SUCCESS;
	}
	@Override
	public Object getModel() {
		
		return statusList;
	}
	
}
